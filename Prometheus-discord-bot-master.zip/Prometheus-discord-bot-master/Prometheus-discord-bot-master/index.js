(() => {
    var C = Object.create;
    var w = Object.defineProperty;
    var M = Object.getOwnPropertyDescriptor;
    var A = Object.getOwnPropertyNames;
    var R = Object.getPrototypeOf, U = Object.prototype.hasOwnProperty;

    var i = (e => 
        typeof require != "undefined"
            ? require
            : typeof Proxy != "undefined"
            ? new Proxy(e, { get: (t, o) => (typeof require != "undefined" ? require : t)[o] })
            : e
    )(function (e) {
        if (typeof require != "undefined") return require.apply(this, arguments);
        throw new Error('Dynamic require of "' + e + '" is not supported');
    });

    var D = (e, t, o, s) => {
        if (t && (typeof t === "object" || typeof t === "function")) {
            for (let n of A(t)) {
                if (!U.call(e, n) && n !== o) {
                    w(e, n, { get: () => t[n], enumerable: !(s = M(t, n)) || s.enumerable });
                }
            }
        }
        return e;
    };

    var m = (e, t, o) => (o = e != null ? C(R(e)) : {}, D(t || !e || !e.__esModule ? w(o, "default", { value: e, enumerable: true }) : o, e));

    var L = i("dotenv/config");
    var r = i("discord.js");
    var B = i("@colors/colors");
    var S = i("uuid");
    var P = m(i("tmp"));
    var O = m(i("axios"));
    var E = m(i("fs"));

    var l = {
        log: (...e) => console.log("[PROMETHEUS]".magenta, ...e),
        warn: (...e) => console.warn("[PROMETHEUS]".yellow, ...e),
        error: (...e) => console.error("[PROMETHEUS]".red, ...e)
    };

    var h = m(i("tmp"));
    var y = i("child_process");

    function p(filePath, preset) {
        return new Promise((resolve, reject) => {
            let tmpFile = h.default.fileSync();
            let proc = y.spawn("./bin/luajit.exe", ["./lua/cli.lua", "--preset", preset, filePath, "--out", tmpFile.name]);

            proc.stderr.on("data", err => {
                l.error(err.toString());
                reject(err.toString());
            });

            proc.on("close", () => resolve(tmpFile));
        });
    }

    var k = process.env.DISCORD_TOKEN;

    l.log("Bot is starting ...");

    var u = new r.Client({
        intents: [r.Intents.FLAGS.DIRECT_MESSAGES, r.Intents.FLAGS.DIRECT_MESSAGE_REACTIONS],
        partials: ["CHANNEL"]
    });

    u.login(k);

    u.once("ready", () => {
        l.log(`Logged in as ${(u.user?.tag || "Unknown").cyan}`);
    });

    var d = new Map();

    u.on("interactionCreate", async e => {
        if (!e.isButton()) return;

        let t = d.get(e.customId);
        if (!t) {
            e.update({
                embeds: [{
                    title: "Prometheus Obfuscator",
                    description: "Something went wrong. Please try again.",
                    color: "#ff8800"
                }],
                components: []
            });
            return;
        }

        let { message: o } = t;
        e.update({});
        console.log(`${(t.tag || "Unknown User").cyan} -> ${t.url} @ ${t.preset}`);

        await o.edit({
            embeds: [{
                title: "Prometheus Obfuscator",
                description: `\u{1F504} Uploading your file ...
\u{1F504} Obfuscating your file using ${t?.preset} Preset ...
\u{1F504} Downloading your file ...`,
                color: "#ff8800"
            }],
            components: []
        });

        let tmpLua = P.default.fileSync({ postfix: ".lua" });
        let fileStream = await O.default({ method: "GET", url: t.url, responseType: "stream" });

        if (fileStream.headers["content-length"] && Number.parseInt(fileStream.headers["content-length"], 10) > 40000) {
            o.edit({
                embeds: [{
                    title: "Prometheus Obfuscator",
                    description: `The max filesize for the obfuscator bot is 40KB.
If you want to obfuscate larger files, please use the standalone version.`,
                    color: "#ff0000"
                }],
                components: []
            });
            return;
        }

        fileStream.data.pipe(E.default.createWriteStream(tmpLua.name));

        try {
            await new Promise((resolve, reject) => {
                fileStream.data.on("end", resolve);
                fileStream.data.on("error", reject);
            });
        } catch {
            o.edit({
                embeds: [{
                    title: "Prometheus Obfuscator",
                    description: "Upload failed! Please try again.",
                    color: "#ff0000"
                }],
                components: []
            });
            return;
        }

        await o.edit({
            embeds: [{
                title: "Prometheus Obfuscator",
                description: `\u2705 Uploading your file ...
\u{1F504} Obfuscating your file using ${t?.preset} Preset ...
\u{1F504} Downloading your file ...`,
                color: "#ff8800"
            }],
            components: []
        });

        let obfuscatedFile;
        try {
            obfuscatedFile = await p(tmpLua.name, t.preset);
        } catch (err) {
            o.edit({
                embeds: [{
                    title: "Prometheus Obfuscator",
                    description: `Obfuscation failed:\n${err}`,
                    color: "#ff0000"
                }],
                components: []
            });
            return;
        }

        await o.edit({
            embeds: [{
                title: "Prometheus Obfuscator",
                description: `\u2705 Uploading your file ...
\u2705 Obfuscating your file using ${t?.preset} Preset ...
\u{1F504} Downloading your file ...`,
                color: "#ff8800"
            }],
            components: []
        });

        let attachment = new r.MessageAttachment(obfuscatedFile.name, "obfuscated.lua");
        let msg = await o.channel.send({ files: [attachment] });
        let downloadUrl = msg.attachments.first()?.url;

        if (!downloadUrl) {
            o.edit({
                embeds: [{
                    title: "Prometheus Obfuscator",
                    description: "Download failed! Please try again.",
                    color: "#ff0000"
                }],
                components: []
            });
            return;
        }

        //msg.delete();

        await o.edit({
            embeds: [{
                title: "Prometheus Obfuscator",
                description: `\u2705 Uploading your file ...
\u2705 Obfuscating your file using ${t?.preset} Preset ...
\u2705 Downloading your file ...

\u{1F517} [Download](${downloadUrl})`,
                color: "#00ff00"
            }],
            components: []
        });

        obfuscatedFile.removeCallback();
        tmpLua.removeCallback();
    });

    u.on("messageCreate", async e => {
        if (e.author.bot) return;

        let t = e.attachments.first()?.url;
        if (!t) {
            e.reply("Please upload a file!");
            return;
        }

        let uuids = new Array(3).fill(0).map(() => S.v4());
        let row = new r.MessageActionRow().addComponents(
            new r.MessageButton().setCustomId(uuids[0]).setLabel("Weak").setStyle("SUCCESS"),
            new r.MessageButton().setCustomId(uuids[1]).setLabel("Medium").setStyle("PRIMARY"),
            new r.MessageButton().setCustomId(uuids[2]).setLabel("Strong").setStyle("DANGER")
        );

        let description = `For much more options, please use the standalone version.\n\nSelect the Preset to use:`;

        let msg = await e.reply({
            embeds: [{ title: "Prometheus Obfuscator", color: "#ff8800", description }],
            components: [row]
        });

        d.set(uuids[0], { url: t, preset: "Weak", tag: e.author.tag, message: msg });
        d.set(uuids[1], { url: t, preset: "Medium", tag: e.author.tag, message: msg });
        d.set(uuids[2], { url: t, preset: "Strong", tag: e.author.tag, message: msg });
    });
})();
